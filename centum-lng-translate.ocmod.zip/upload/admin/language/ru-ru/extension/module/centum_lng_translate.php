<?php

/**
 * main
 */
$_['heading_title']  = 'Centum-D Перевод через google translate api';
$_['text_extension'] = 'Расширения';
$_['text_success']   = 'Настройки успешно изменены!';
$_['text_edit']      = 'Настройки модуля';
$_['text_enabled']   = 'Включено';
$_['text_disabled']  = 'Выключено';
$_['text_translate']  = 'Перевести';
$_['text_console']  = 'Консоль';
$_['text_console_setting']  = 'Настройка консоли';

/**
 * other translate
 */
$_['text_success']   = 'все окей';
$_['text_errors']   = 'перевод совпал с исходным текстом';
$_['text_status']   = 'Статус';
$_['text_name']   = 'Название модуля';
$_['text_type']   = 'Тип перевода';
$_['text_type_product']   = 'Продукты';
$_['text_type_attribute']   = 'Атрибуты';
$_['text_type_product_attribute']   = 'Атрибуты товара';
$_['label_translate_product_attribute']   = 'Какой атрибут перевести';
$_['text_type_category']   = 'Категории';
$_['text_translate_from']    = 'С какого языка переводить';
$_['text_translate_to']      = 'В какой переводить';
$_['text_translate_attribute_equal'] = 'Одинаковые атрибуты за один раз';
$_['text_total_not_translated_products_found'] = 'Всего найдено не переведенных';
$_['text_not_translated_products_found'] = 'Список для перевода';
$_['label_all_translate'] = 'Только не переведенные';
$_['text_cron'] = 'Ссылка на крон';
$_['label_state_active_only_translate'] = 'Только в статусе "Активен"';
$_['label_count_in_one_go_translate'] = 'Переводить за один раз';
$_['label_console_show_product_need_translate'] = 'Показывать что необходимо перевести';
$_['title_console_show_product_need_translate'] = 'Будут отображены id номера с ссылками. Если много елементов, лучше не включать!';
$_['help_translate_attribute_equal'] = 'Если названия атрибутов совпадут, то будут переведены все совпавшие атрибуты за один проход';
$_['help_state_active_only_translate'] = 'Переводить только влюченные елементы, или переводить не взирая на статус (Да/Нет)';
$_['help_all_translate'] = 'Переводить только те которые еще не переведены, или все (Да/Нет)';
$_['help_count_in_one_go_translate'] = 'Сколько елементов должно быть переведено после нажатия кнопки <Перевести>';


$_['api_tooltip'] = 'Если есть api key будет использован Google Translation Rest API';
$_['text_api_key'] = 'API Key для <a href="https://cloud.google.com/translate/docs/reference/rest/v2/translate">Google Translation API</a>';

