<?php

class ControllerExtensionModuleCentumLngTranslate extends Controller
{
    public function index()
    {
        require('admin/model/extension/module/centum_lng_translate.php');

        $adminModelCentumTranslate = new ModelExtensionModuleCentumLngTranslate($this->registry);

        $moduleId = (isset($_GET['module_id'])) ? (int)$_GET['module_id'] : 0;

        if ($moduleId > 0) {
            echo $adminModelCentumTranslate->setProductsWithOutTranslate($moduleId);
        }
    }
}


