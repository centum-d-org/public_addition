<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       https://centum-d.com
 * @since      1.0.0
 *
 * @package    Centum_Lazy_Load
 * @subpackage Centum_Lazy_Load/admin/partials
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
