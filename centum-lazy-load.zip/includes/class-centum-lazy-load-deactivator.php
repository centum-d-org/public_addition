<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://centum-d.com
 * @since      1.0.0
 *
 * @package    Centum_Lazy_Load
 * @subpackage Centum_Lazy_Load/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Centum_Lazy_Load
 * @subpackage Centum_Lazy_Load/includes
 * @author     Centum-D <office@centum-d.com>
 */
class Centum_Lazy_Load_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
