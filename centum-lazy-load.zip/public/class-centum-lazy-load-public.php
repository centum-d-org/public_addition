<?php

/**
 * The public-facing functionality of the plugin.
 *
 * @link       https://centum-d.com
 * @since      1.0.0
 *
 * @package    Centum_Lazy_Load
 * @subpackage Centum_Lazy_Load/public
 */

/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the public-facing stylesheet and JavaScript.
 *
 * @package    Centum_Lazy_Load
 * @subpackage Centum_Lazy_Load/public
 * @author     Centum-D <office@centum-d.com>
 */
class Centum_Lazy_Load_Public {

    /**
     * The ID of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $centum_lazy_load    The ID of this plugin.
     */
    private $centum_lazy_load;

    /**
     * The version of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $version    The current version of this plugin.
     */
    private $version;

    /**
     * Initialize the class and set its properties.
     *
     * @since    1.0.0
     * @param      string    $centum_lazy_load       The name of the plugin.
     * @param      string    $version    The version of this plugin.
     */
    public function __construct( $centum_lazy_load, $version ) {

        $this->centum_lazy_load = $centum_lazy_load;
        $this->version = $version;

    }

    /**
     * Register the stylesheets for the public-facing side of the site.
     *
     * @since    1.0.0
     */
    public function enqueue_styles() {

        /**
         * This function is provided for demonstration purposes only.
         *
         * An instance of this class should be passed to the run() function
         * defined in Plugin_Name_Loader as all of the hooks are defined
         * in that particular class.
         *
         * The Plugin_Name_Loader will then create the relationship
         * between the defined hooks and the functions defined in this
         * class.
         */

        wp_enqueue_style( $this->centum_lazy_load, plugin_dir_url( __FILE__ ) . 'css/centum-lazy-load-public.css', array(), $this->version, 'all' );

    }

    /**
     * Register the JavaScript for the public-facing side of the site.
     *
     * @since    1.0.0
     */
    public function enqueue_scripts() {

        /**
         * This function is provided for demonstration purposes only.
         *
         * An instance of this class should be passed to the run() function
         * defined in Plugin_Name_Loader as all of the hooks are defined
         * in that particular class.
         *
         * The Plugin_Name_Loader will then create the relationship
         * between the defined hooks and the functions defined in this
         * class.
         */

        wp_enqueue_script( $this->centum_lazy_load.'-1', plugin_dir_url( __FILE__ ) . 'js/lozad.min.js', array( 'jquery' ), $this->version, false );
        wp_enqueue_script( $this->centum_lazy_load, plugin_dir_url( __FILE__ ) . 'js/centum-lazy-load-public.js', array( 'jquery' ), $this->version, false );


    }


    /**
     * Add several attributes to the picture, such as decoding, loading
     *
     * @param $content
     * @return string|string[]
     * @since    1.0.0
     */
    public function lazyIMGs($content) {
        $doc = new DOMDocument();
        $arrayAlreadyUpdated = [];
        @$doc->loadHTML($content);
        $tags = $doc->getElementsByTagName('img');

        foreach ($tags as $tag) {
            if(!in_array($tag->getAttribute('src'), $arrayAlreadyUpdated)) {
                $content = str_replace('src="' . $tag->getAttribute('src') . '"', 'decoding="async" src="' . $tag->getAttribute('src') . '" data-srcset="' . $tag->getAttribute('src') . '" srcset="' . plugin_dir_url(__FILE__) . 'img/preloader.gif"', $content);
            }

            $arrayAlreadyUpdated[] = $tag->getAttribute('src');
        }

        return $content;
    }

}