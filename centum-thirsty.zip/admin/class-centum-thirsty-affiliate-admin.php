<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @link       https://centum-d.com
 * @since      1.0.0
 *
 * @package    Centum_Thirsty_Affiliate
 * @subpackage Centum_Thirsty_Affiliate/admin
 * @author     Centum-D <office@centum-d.com>
 */
class Centum_Thirsty_Affiliate_Admin {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.1
	 * @access   private
	 * @var      string    $centum_thirsty_affiliate    The ID of this plugin.
	 */
	private $centum_thirsty_affiliate;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.1
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.1
	 * @param      string    $centum_thirsty_affiliate      The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $centum_thirsty_affiliate, $version ) {

		$this->centum_thirsty_affiliate = $centum_thirsty_affiliate;
		$this->version = $version;

	}

	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since    1.0.1
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Plugin_Name_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Plugin_Name_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style( $this->centum_thirsty_affiliate, plugin_dir_url( __FILE__ ) . 'css/centum-thirsty-affiliate-admin.css', array(), $this->version, 'all' );

	}

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since    1.0.1
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Plugin_Name_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Plugin_Name_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_script( $this->centum_thirsty_affiliate, plugin_dir_url( __FILE__ ) . 'js/centum-thirsty-affiliate-admin.js', array( 'jquery' ), $this->version, false );

	}

}
