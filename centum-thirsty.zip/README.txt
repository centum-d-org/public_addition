=== Centum lazy load ===
Contributors: centumd
Tags: lazy load, real lazy image
Requires at least: 4.7
Tested up to: 5.4
Requires PHP: 7.0
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

== Description ==

Plugin to implement lazy loading of images

== Frequently Asked Questions ==

= Install =

1. Upload `centum-lazy-load` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Changelog ==

- 1.0.0
* first release