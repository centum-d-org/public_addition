<?php
require_once($_SERVER['DOCUMENT_ROOT'] . '/wp-load.php');

if (isset($_POST['delimiter']) && !empty($_FILES['csv']['name'])) {
    $delimiter = $_POST['delimiter'];
    $numCols = $_POST['number-col'];
    $uploadDir = $_SERVER['DOCUMENT_ROOT'] . '/wp-content/plugins/centum-thirsty/tmp/';
    $uploadFile = $uploadDir . basename($_FILES['csv']['name']);
    $skip = 1;
    $result = '';

    if (!move_uploaded_file($_FILES['csv']['tmp_name'], $uploadFile)) {
        if (WP_DEBUG === true) {
            error_log('Upload file error, plugin centum-thirsty', 3, $_SERVER['DOCUMENT_ROOT'] . '/wp-content/plugins/centum-thirsty/log/debug.log');
        }
    }

    if (($handle = fopen($uploadFile, "r")) !== FALSE) {
        while (($data = fgetcsv($handle, 10000, $delimiter)) !== FALSE) {
            if ($skip == 1) {
                $result .= $data[0] . $delimiter . $data[1] . $delimiter . $data[2] . $delimiter . $data[3] . $delimiter . $data[4] . $delimiter . $data[5] . $delimiter . $data[6] . $delimiter . $data[7] . $delimiter . $data[8] . $delimiter . $data[9] . $delimiter . $data[10] . $delimiter . $data[11] . $delimiter . $data[12] . $delimiter . $data[13] . $delimiter . $data[14] . $delimiter . "\n";
                $skip = 2;
                continue;
            }

            $productNameSlug = sanitize_title($data[0]);

            /**
             * check post, if exist then update else create
             */
            $postsCheck = get_posts([
                'name' => $productNameSlug,
                'post_type' => 'thirstylink'
            ]);

            $foundPost = (!empty($postsCheck)) ? $postsCheck[0] : null;

            /**
             * array setting for post
             */
            $affiliatePost = [
                'post_title' => $data[1],
                'post_name' => $data[0],
                'post_content' => '',
                'post_type' => 'thirstylink',
                'post_status' => 'publish',
                'comment_status' => 'closed',
                'ping_status' => 'closed',
                'menu_order' => 0,
                'post_author' => 1,
                'meta_input' => [
                    '_edit_last' => 1,
                    '_ta_destination_url' => $data[2],
                    '_ta_no_follow' => 'global',
                    '_ta_new_window' => 'global',
                    '_ta_pass_query_str' => 'global',
                    '_ta_redirect_type' => 'global',
                    '_ta_rel_tags' => '',
                    '_ta_css_classes' => '',
                    '_ta_category_slug_id' => 0,
                    '_ta_category_slug' => '',
                ],
            ];

            if (!is_null($foundPost)) {
                wp_update_post($affiliatePost);
            }else{
                wp_insert_post($affiliatePost);
            }

            $urlAffiliates = get_site_url() . '/recommends/' . $productNameSlug;
            $result .= $data[0] . $delimiter . $data[1] . $delimiter . $urlAffiliates . $delimiter . $data[3] . $delimiter . $data[4] . $delimiter . $data[5] . $delimiter . $data[6] . $delimiter . $data[7] . $delimiter . $data[8] . $delimiter . $data[9] . $delimiter . $data[10] . $delimiter . $data[11] . $delimiter . $data[12] . $delimiter . $data[13] . $delimiter . $data[14] . $delimiter . "\n";
        }

        fclose($handle);
    }

    header('Content-type: text/csv; charset=utf-8');
    header('Content-disposition: attachment; filename=final_' . date("Ymd_His") . '.csv');

    echo $result;
}else{
    echo '<h1 style="color:red">Separator not specified or no csv file selected</h1><h2 onclick="window.history.back();" style="cursor:pointer;">< come back</h2>';
}