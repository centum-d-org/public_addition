<?php
/**
 * Define the internationalization functionality.
 *
 * Loads and defines the internationalization files for this plugin
 * so that it is ready for translation.
 *
 * @link       https://centum-d.com
 * @since      1.0.1
 * @package    Centum_Thirsty_Affiliate
 * @subpackage Centum_Thirsty_Affiliate/includes
 * @author     Centum-D <office@centum-d.com>
 */
class Centum_Thirsty_Affiliate_i18n {

	/**
	 * Load the plugin text domain for translation.
	 *
	 * @since    1.0.0
	 */
	public function load_plugin_textdomain() {

		load_plugin_textdomain(
			'centum-thirsty-affiliate',
			false,
			dirname( dirname( plugin_basename( __FILE__ ) ) ) . '/languages/'
		);

	}



}
