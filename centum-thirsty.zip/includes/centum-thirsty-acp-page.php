<div class="wrap">
    <h1>Add file csv</h1>
    <textarea disabled cols="200" rows="7" contenteditable="true" wrap="off">
        For the functionality to work correctly, the "ThirstyAffiliates lite" plugin must be installed.
            - if there is a special delimiter in the csv file, then specify it
            - select csv file
            - click the button "Process file"
        Example csv
        SKU, Name, External URL, Attribute 1 value(s), Categories, Attribute 2 value(s), Size, Currency, Type, Attribute 1 name, Attribute 2 name, Images, In stock?, Regular price, Sale price
    </textarea>
    <form action="/wp-content/plugins/centum-thirsty/includes/centum-csv.php" method="post" enctype="multipart/form-data">
        <p><label>Csv separator: <input type="text" name="delimiter" value=","></label></p>
        <p><input type="file" name="csv"></p>
        <p><input type="submit" value="Process file" class="button button-primary button-large"></p>
    </form>
</div>